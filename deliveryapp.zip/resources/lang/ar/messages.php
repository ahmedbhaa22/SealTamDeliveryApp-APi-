<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'wrongemailorpassword' => 'كلمة المرور او البريد الالكترونى غير صحيح',
    'NoDriverAvailAbleToAcceptThisRequest'=>"لا يوجد طيارين متاحين الان",
    'YouCannotAddOrdersForThisDriver'=>"هذا الطيار لا بمكنه استقبال اى طلبات اخرى",
    'Driver_Left'=>"هذا الطيار  غادر",
    'Driver_Arrived'=>"الطيار وصل بالفعل لا يمكنك الغاء الطلب",
    'order_seald'=>"لا يمكن الغاء هذا الطلب"


];
