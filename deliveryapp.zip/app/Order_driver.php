<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order_driver extends Model
{
     protected $table = 'order_drivers';
      protected $guarded = [];
}
