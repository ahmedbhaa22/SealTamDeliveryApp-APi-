<?php

namespace App\Models\Dashboard;

use Illuminate\Database\Eloquent\Model;

class admin_types extends Model
{
}
