<?php
namespace App\Http\ViewModel;

 class ResultVM
{
   public  $IsSuccess = true;
   public  $FaildReason='';
   public  $Data ;
}
